﻿
public interface IUpdate
{
}