﻿
/// <summary>
/// 主要常用Update更新
/// </summary>
   public interface IMainUpdate:IUpdate
    {
    /// <summary>
    ///更新
    /// </summary>
    void OnUpdate();
    }
