﻿
/// <summary>
/// 固定的update更新接口
/// </summary>
public interface IFixedUpdate : IUpdate
{
    //固定的更新
    void OnFixedUpdate();
}
