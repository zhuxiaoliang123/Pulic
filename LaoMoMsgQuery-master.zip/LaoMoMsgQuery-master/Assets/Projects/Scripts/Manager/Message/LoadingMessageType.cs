﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum LoadingMessageType
{
    //加载开始
    LoadingStart,
    //加载进度
    LoadingProcess,
    //加载完成
    LoadingComplete,
}