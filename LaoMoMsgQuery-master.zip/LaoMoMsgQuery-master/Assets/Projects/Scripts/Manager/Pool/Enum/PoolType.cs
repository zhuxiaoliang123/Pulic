﻿
namespace MTFrame. MTPool
{
    /// <summary>
    /// 池类型
    /// </summary>
    public enum PoolType
    {
        /// <summary>
        /// 通用
        /// </summary>
        GenericProp,
        BigImage,
        CirleImage,
        ResultText,
    }
}
