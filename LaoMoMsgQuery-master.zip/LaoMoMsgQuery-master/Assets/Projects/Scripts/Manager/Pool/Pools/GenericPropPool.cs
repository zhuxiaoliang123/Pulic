﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTFrame.MTPool
{
    /// <summary>
    /// 通用池
    /// </summary>
    public class GenericPropPool : BasePool
    {
    }

    public class BigImagePool:BasePool
    {

    }

    public class CirleImagePool:BasePool
    {

    }

    public class ResultTextPool:BasePool
    {

    }
}
