﻿/// <summary>
/// Panel的类型(显示位置)
/// </summary>
public enum WindowTypeEnum
{
    //世界
    World,
    //屏幕
    Screen,
    //前景
    ForegroundScreen
}
