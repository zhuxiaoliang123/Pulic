﻿
   public struct SourcesPath
{
    private const string Player = "Model/Player/";
    private const string Enemy = "Model/Enemy/";
    private const string GenericProp= "Model/GenericProp/";

    public struct PlayerPath
    {
        //public const string Cube = Player + "Cube";
    }
    public struct EnemyPath
    {
        //public const string Cube = Enemy + "Cube";
    }
    public struct GenericPropPath
    {
        //public const string Cube = GenericProp + "Cube";
    }


}
