﻿
   public struct ScenePath
{
    public const string Main ="Main";

    public const string MultiInter = "MultiInter";
}
