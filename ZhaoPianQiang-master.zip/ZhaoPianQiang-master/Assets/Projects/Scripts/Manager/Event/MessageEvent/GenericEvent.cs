﻿
using System;
using System.Collections.Generic;
using UnityEngine;
namespace MTFrame.MTEvent
{
    /// <summary>
    /// 常用事件
    /// </summary>
    public class GenericEvent : BaseEvent
    {

    }
}