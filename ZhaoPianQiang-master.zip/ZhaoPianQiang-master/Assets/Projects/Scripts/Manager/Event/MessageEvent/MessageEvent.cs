﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MTFrame.MTEvent
{
    public class MessageEvent : BaseEvent
    {

    }
}